/* Copyright (c) 2017.  Qualcomm Atheros, Inc.
All rights reserved.

Qualcomm Atheros Confidential and Proprietary.

*/

/**
 * @file qapi_location_txm.h
 *
 * @brief 
 *
 * @details 
 */

#ifndef __QAPI_LOCATION_TXM_H__ // [
#define __QAPI_LOCATION_TXM_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "qapi_location.h"
   

#ifdef __cplusplus
} /* closing brace for extern "C" */
#endif

                                                            /** @} */
#endif // ] #ifndef __QAPI_LOCATION_TXM_H__

