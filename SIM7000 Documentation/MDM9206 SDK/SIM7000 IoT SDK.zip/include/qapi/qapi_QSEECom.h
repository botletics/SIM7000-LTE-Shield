/**
 * @file qapi_QSEECom.h
 *
 * @brief HLOS QSEEComAPI Library Functions
 *
 * Contains the library functions for accessing the QSEECom driver.
 */
/*
 * Copyright (c) 2010-2018 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 */

#ifndef __QAPI_QSEECOM_H_
#define __QAPI_QSEECOM_H_

#include <stdint.h>
#include <stdbool.h>
#include "qseecom.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @addtogroup qapi_qsee
@{ */

/**
 * @brief Handle to the loaded trusted application (TA).
 *
 * This handle is returned by qapi_QSEECom_start_app().
 */
typedef struct qapi_QSEECom_handle {
    unsigned char *mem_sbuffer;     /**< Not used -- set to NULL. */
} qapi_QSEECom_handle_t;

/**
 * @brief Starts a trusted application.
 *
 * Loads and starts a trusted application. The application is verified as
 * secure by digital signature verification.
 *
 * A trusted application is built using the QTEE tool chain. The binaries
 * are split into multiple files and are saved to the file system.
 *
 * Example: \n
 *
 * The directory "/firmware/image" contains a trusted application named "my_ta". The
 * trusted application is split into "my_ta.b00", "my_ta.b01", "my_ta.b02",
 * "my_ta.b03", "my_ta.b04", "my_ta.b05", and "my_ta.mdt".
 * @code
 * qapi_QSEECom_handle_t *handle = NULL;
 * qapi_QSEECom_start_app(&handle, "/firmware/image", "my_ta", 0);
 * ...
 * qapi_QSEECom_shutdown_app(&handle);
 * @endcode
 *
 * @param[in,out] clnt_handle Handle to the loaded trusted application.
 * @param[in] path Name of the directory that contains the trusted application.
 * @param[in] fname Name of the trusted application file name without the extension.
 * @param[in] sb_size Not used -- set to 0.
 *
 * @return Zero on success, negative value on failure.
 */
int qapi_QSEECom_start_app(qapi_QSEECom_handle_t **clnt_handle,
        const char *path, const char *fname, uint32_t sb_size);

/**
 * @brief Shuts down a started trusted application.
 *
 * See qapi_QSEECom_start_app() for a usage example.
 *
 * @param[in] handle Handle to the loaded trusted application.
 *
 * @return Zero on success, negative on failure.
 */
int qapi_QSEECom_shutdown_app(qapi_QSEECom_handle_t **handle);

/** @} */ /* end_addtogroup qapi_qsee */

#ifdef __cplusplus
}
#endif

#endif
