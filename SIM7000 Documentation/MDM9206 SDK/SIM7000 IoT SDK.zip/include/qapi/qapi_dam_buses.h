#ifndef __QAPI_DAM_BUSES_H__
#define __QAPI_DAM_BUSES_H__

/**
 * @file qapi_dam_buses.h
 */

/*==================================================================================================
Copyright (c) 2017 Qualcomm Technologies, Inc.
        All Rights Reserved.
Qualcomm Technologies, Inc. Confidential and Proprietary.

==================================================================================================*/
/*==================================================================================================
                                            DESCRIPTION
====================================================================================================

==================================================================================================*/
/*==================================================================================================
Edit History

$Header: //components/rel/iot-sdk/1.0/include/qapi/qapi_dam_buses.h#2 $

when       who     what, where, why
--------   ---     --------------------------------------------------------
09/11/17    vg     Added spi DAM changes
02/28/17   ska     Created Initial version

==================================================================================================*/

/*==================================================================================================
                                           INCLUDE FILES
==================================================================================================*/
#include "qurt_txm_qapi_fwk.h"
#include "qapi_txm_base.h"



/*==================================================================================================
                                             ENUMERATIONS
==================================================================================================*/
#define TXM_QAPI_BUSES_UART_BASE (TXM_QAPI_BUSES_BASE)
#define TXM_QAPI_BUSES_SPI_BASE  (TXM_QAPI_BUSES_BASE + 30)
#define TXM_QAPI_BUSES_I2C_BASE  (TXM_QAPI_BUSES_BASE + 60)

#define TXM_QAPI_BUSES_UART_CB_BASE  (CUSTOM_CB_QAPI_BUSES_BASE)
#define TXM_QAPI_BUSES_SPI_CB_BASE   (CUSTOM_CB_QAPI_BUSES_BASE + 10)
#define TXM_QAPI_BUSES_I2C_CB_BASE   (CUSTOM_CB_QAPI_BUSES_BASE + 15)

#endif

