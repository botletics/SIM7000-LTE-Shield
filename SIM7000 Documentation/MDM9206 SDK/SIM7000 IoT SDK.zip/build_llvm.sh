#!/bin/sh

DAM_RO_BASE=0x43000000


export TOOLCHAIN_PATH=/opt/QualComm/llvm/bin
export LLVMLINK_PATH=/opt/QualComm/llvm/tools/bin
export LLVMLIB=/opt/QualComm/llvm/lib/clang/4.0.11/lib
export TOOLCHAIN_PATH_STANDARdS=/opt/QualComm/llvm/armv7m-none-eabi/libc/include


export SENSOR_ELF_OUTPUT_PATH="./bin"
export DAM_INC_BASE="./include"
export DAM_LIB_PATH="./libs"
export DAM_SRC_PATH="./src/app"

export DEMO_APP_SRC_PATH="./src/app"
export DEMO_APP_OUTPUT_PATH="./src/app/build"
export SENSOR_DAM_DEMO_LD_PATH="./src/build"




export DAM_LIBNAME="txm_lib.lib"
export TIMER_LIBNAME="timer_dam_lib.lib"


export DAM_ELF_NAME="cust_app.elf"
export DAM_TARGET_BIN="cust_app.bin"
export DAM_MAP_NAME="cust_app.map"

mkdir bin
if [ $# -eq 1 ];
  then
    if [ $1 == "-c" ];
	   then
		  echo "Cleaning..."
		  rm -rf $SENSOR_ELF_OUTPUT_PATH/*
		  rm -rf $DEMO_APP_OUTPUT_PATH/*
		  echo "Done."
		  exit
	   else
        DAM_RO_BASE=$1
	 fi
fi

echo "Application RO base selected = $DAM_RO_BASE"

export DAM_CPPFLAGS="-DQAPI_TXM_MODULE -DTXM_MODULE -DTX_DAM_QC_CUSTOMIZATIONS -DTX_ENABLE_PROFILING -DTX_ENABLE_EVENT_TRACE -DTX_DISABLE_NOTIFY_CALLBACKS  -DFX_FILEX_PRESENT -DTX_ENABLE_IRQ_NESTING  -DTX3_CHANGES"

export DAM_CFLAGS="-marm -target armv7m-none-musleabi -mfloat-abi=softfp -mfpu=none -mcpu=cortex-a7 -mno-unaligned-access  -fms-extensions -Osize -fshort-enums -Wbuiltin-macro-redefined"

export DAM_INCPATHS="-I $DAM_INC_BASE -I $DAM_INC_BASE/threadx_api -I $DAM_INC_BASE/qapi -I $DAM_INC_BASE\qmi -I $DAM_CPPFLAGS -I $LLVMLIB -I $TOOLCHAIN_PATH_STANDARdS -I DAM_CFLAGS"


#Turn on verbose mode by default
#set -x;

echo "Compiling ThingSpace application"

$TOOLCHAIN_PATH/clang -E  $DAM_CPPFLAGS $DAM_CFLAGS $DAM_SRC_PATH/txm_module_preamble_llvm.S > txm_module_preamble_llvm_pp.S

$TOOLCHAIN_PATH/clang -c $DAM_CPPFLAGS $DAM_CFLAGS txm_module_preamble_llvm_pp.S -o $DEMO_APP_OUTPUT_PATH/txm_module_preamble_llvm.o

rm txm_module_preamble_llvm_pp.S
rm build.log

for file in $DEMO_APP_SRC_PATH/*
do
    if [ -d "$file" ]; then
        if [ "build" != "${file##*/}" ]; then
            echo "compile ${file##*/} ......"
            $TOOLCHAIN_PATH/clang -c $DAM_CPPFLAGS $DAM_CFLAGS  $DAM_INCPATHS $file/*.c  >> build.log 2>&1
        fi
    elif [ -f "$file" ]; then
        if [ 'extension: ${file##*.}' == 'c' ];then
            $TOOLCHAIN_PATH/clang -c $DAM_CPPFLAGS $DAM_CFLAGS  $DAM_INCPATHS $file >> build.log 2>&1
        fi
    fi
done

mv *.o $DEMO_APP_OUTPUT_PATH


echo "Linking ThingSpace application"
$TOOLCHAIN_PATH/clang++ -d -o $SENSOR_ELF_OUTPUT_PATH/$DAM_ELF_NAME -target armv7m-none-musleabi -fuse-ld=qcld -lc++ -Wl,-mno-unaligned-access -fuse-baremetal-sysroot -fno-use-baremetal-crt -Wl,-entry=$DAM_RO_BASE $DEMO_APP_OUTPUT_PATH/txm_module_preamble_llvm.o -Wl,-T$SENSOR_DAM_DEMO_LD_PATH/cust_app.ld -Wl,-Map=$SENSOR_ELF_OUTPUT_PATH/$DAM_MAP_NAME -Wl,-gc-sections $DEMO_APP_OUTPUT_PATH/*.o $DAM_LIB_PATH/*.lib >> build.log 2>&1
$LLVMLINK_PATH/llvm-elf-to-hex.py   --output $SENSOR_ELF_OUTPUT_PATH/$DAM_TARGET_BIN --bin $SENSOR_ELF_OUTPUT_PATH/$DAM_ELF_NAME >> build.log 2>&1
echo "Demo application is built at" $SENSOR_ELF_OUTPUT_PATH/$DAM_TARGET_BIN
echo "Please refer build.log about compile result!!!"

