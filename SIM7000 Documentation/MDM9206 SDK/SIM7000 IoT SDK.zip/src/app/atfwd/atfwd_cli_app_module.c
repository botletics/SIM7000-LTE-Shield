/*!
  @file
  atfwd_cli_app_module.c

  @brief
  ATFWD test application functionality 
*/

/*===========================================================================

  Copyright (c) 2017 Qualcomm Technologies, Inc. All Rights Reserved

  Qualcomm Technologies Proprietary

  Export of this technology or software is regulated by the U.S. Government.
  Diversion contrary to U.S. law prohibited.

  All ideas, data and information contained in or disclosed by
  this document are confidential and proprietary information of
  Qualcomm Technologies, Inc. and all rights therein are expressly reserved.
  By accepting this material the recipient agrees that this material
  and the information contained therein are held in confidence and in
  trust and will not be used, copied, reproduced in whole or in part,
  nor its contents revealed in any manner to others without the express
  written permission of Qualcomm Technologies, Inc.

===========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>

#include "../qcli/qcli.h"
#include "../qcli/qcli_api.h"
#include "../qcli/pal.h"
#include "atfwd_cli_app.h"

#include "qapi_atfwd.h"
#include "qapi_socket.h"
#include "qapi_fs.h"

#include "txm_module.h"

#define QCLI_AT_CMD_RESP_LEN_MAX_V01 100

#define QCLI_AT_URC_LEN_MAX_V01 64

#define QCLI_AT_RESULT_ERROR_V01 0 /**<  Result ERROR. 
                                         This is to be set in case of ERROR or CME ERROR. 
                                         The response buffer contains the entire details. */
#define QCLI_AT_RESULT_OK_V01 1 /**<  Result OK. This is to be set if the final response 
                                      must send an OK result code to the terminal. 
                                      The response buffer must not contain an OK.  */

#define QCLI_AT_MASK_EMPTY 0  /**<  Denotes a feed back mechanism for AT reg and de-reg */
#define QCLI_AT_MASK_NA_V01 1 /**<  Denotes presence of Name field  */
#define QCLI_AT_MASK_EQ_V01 2 /**<  Denotes presence of equal (=) operator  */
#define QCLI_AT_MASK_QU_V01 4 /**<  Denotes presence of question mark (?)  */
#define QCLI_AT_MASK_AR_V01 8 /**<  Denotes presence of trailing argument operator */

#define ATFWD_STACK_SIZE (1024*2)
#define ATFWD_PRIORITY 185


extern TX_BYTE_POOL *byte_pool_qcli;
boolean user_space_pool_init = FALSE;
boolean user_space_pool_1 = FALSE;
boolean user_space_pool_2 = FALSE;


TX_THREAD *atfwd_thread_handle1;
TX_THREAD *atfwd_thread_handle2;

/* Forward declarations */
static QCLI_Command_Status_t create_atfwd_thread(uint32_t Parameter_Count, QCLI_Parameter_t *Parameter_List);
static QCLI_Command_Status_t atfwd(uint32_t Parameter_Count, QCLI_Parameter_t *Parameter_List);

static int create_atfwd_thread1(void);
void perform_atfwd_test1(void *args);
static int create_atfwd_thread2(void);
void perform_atfwd_test2(void *args);

const QCLI_Command_t atfwd_cli_app_cmd_list[] =
{
    /* Command_Function, Start_Thread, Command_String, Usage_String, Description */
    {create_atfwd_thread, false, "create_atfwd_thread", "[start thread_number\n"
                           , "Perform ATFWD operations in specified thread number",NULL},
    {atfwd, false, "atfwd", " reg <at_cmds>\n"
                            " dereg <at_cmds>\n"
                            " sendresp <atcmd_name> <response_buf> <result>\n"
                            " sendurc <atcmd_name> <response_buf>\n" , "Perform ATFWD operations",NULL}
};

const QCLI_Command_Group_t atfwd_cli_app_cmd_group =
{
    "atfwd_cli_app",              /* Group_String: will display cmd prompt as "Net> " */
    sizeof(atfwd_cli_app_cmd_list)/sizeof(atfwd_cli_app_cmd_list[0]),   /* Command_Count */
    atfwd_cli_app_cmd_list        /* Command_List */
};

QCLI_Group_Handle_t qcli_atfwd_cli_app_handle;     /* Handle for Net Command Group. */

static void* atfwd_malloc(uint32_t size)
{
  void *ptr = NULL; 
  uint32_t status = 0; 

  status = tx_byte_allocate(byte_pool_qcli, &ptr, size, TX_NO_WAIT);
  if (status != TX_SUCCESS)
  {
    return NULL;
  }

  return ptr;
}

static void atfwd_free(void *ptr)
{
  if (ptr != NULL)
  {
    tx_byte_release(ptr);
    ptr = NULL;
  }
}


/*****************************************************************************
 * This function is used to register the Atfwd Command Group with QCLI.
 *****************************************************************************/
void Initialize_Atfwd_Cli_App_Demo(void)
{
  /* Attempt to reqister the Command Groups with the qcli framework.*/
  qcli_atfwd_cli_app_handle = QCLI_Register_Command_Group(NULL, &atfwd_cli_app_cmd_group);

  if (qcli_atfwd_cli_app_handle)
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Atfwd_Cli_App Registered\n");

  return;
}


int strncasecmp(const char * s1, const char * s2, size_t n)
{
  unsigned char c1, c2;
  int diff;

  if (n > 0)
  {
    do
    {
      c1 = (unsigned char)(*s1++);
      c2 = (unsigned char)(*s2++);
      if (('A' <= c1) && ('Z' >= c1))
      {
        c1 = c1 - 'A' + 'a';
      }
      if (('A' <= c2) && ('Z' >= c2))
      {
        c2 = c2 - 'A' + 'a';
      }
      diff = c1 - c2;

      if (0 != diff)
      {
        return diff;
      }

      if ('\0' == c1)
      {
        break;
      }
    } while (--n);
  }
  return 0;
}

/*****************************************************************************
 * This function is used as a callback to the client.
 *****************************************************************************/

void at_fwd_callback(boolean is_reg, char *atcmd_name, uint8* at_fwd_params, uint8 mask, uint32 at_handle)
{
    int32_t e = -1;
    int i = -1;
    char *at_resp = NULL;
    static int total_cmd_reg = 0;

    QCLI_Printf(qcli_atfwd_cli_app_handle, "In at_fwd_callback\n");
    if (is_reg)
    {
      if (mask == QCLI_AT_MASK_EMPTY)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Last registered AT cmd %s\n",atcmd_name);

        total_cmd_reg+=at_handle;

        QCLI_Printf(qcli_atfwd_cli_app_handle, "Total Registered AT cmds in ATFwD"
                    "with this callback %d \n",total_cmd_reg);
       return;
      }
	
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Atcmd %s is registered\n",atcmd_name);

    if (!strncasecmp(atcmd_name, "+createsock", strlen(atcmd_name)))
    {
      if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_EQ_V01 | QCLI_AT_MASK_AR_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n", atcmd_name);
        QCLI_Printf(qcli_atfwd_cli_app_handle, "The parameters received are %s\n", at_fwd_params);

        if (!strncasecmp((char *)at_fwd_params, "0", strlen((char *)at_fwd_params)))
        {
          i = qapi_socket(AF_UNSPEC, SOCK_DGRAM, 0);
        }
        else if (!strncasecmp((char *)at_fwd_params, "2", strlen((char *)at_fwd_params)))
        {
          i = qapi_socket(AF_INET, SOCK_DGRAM, 0);
        }
        else if (!strncasecmp((char *)at_fwd_params, "3", strlen((char *)at_fwd_params)))
        {
          i = qapi_socket(AF_INET6, SOCK_DGRAM, 0);
        }
        else if (!strncasecmp((char *)at_fwd_params, "4", strlen((char *)at_fwd_params)))
        {
          i = qapi_socket(AF_INET_DUAL46, SOCK_DGRAM, 0);
        }
        else
        {
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Received AT+CREATESOCK with invalid parameters\n");
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Sending an Error Response...\n");
          e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
        }

        at_resp = atfwd_malloc(QCLI_AT_CMD_RESP_LEN_MAX_V01);
        if (at_resp == NULL)
        {
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Memory allocation failure for at_resp\n");
          return;
        }
        memset (at_resp, 0, QCLI_AT_CMD_RESP_LEN_MAX_V01);

        snprintf(at_resp, QCLI_AT_CMD_RESP_LEN_MAX_V01, "SOCKETFD = %d",i);

        e = qapi_atfwd_send_resp(atcmd_name , at_resp , QCLI_AT_RESULT_OK_V01);
        if (at_resp)
        {
          atfwd_free(at_resp);
        }
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Received AT+CREATESOCK without parameters which is not supported\n");
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Sending an Error Response...\n");
        e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
      }
    }
    else if (!strncasecmp(atcmd_name, "+ex1", strlen(atcmd_name)))
    {
      if (mask == (QCLI_AT_MASK_NA_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        e = qapi_atfwd_send_resp(atcmd_name, "Received AT cmd +ex1 with Only Name", QCLI_AT_RESULT_OK_V01);
      }
      else if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_QU_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        e = qapi_atfwd_send_resp(atcmd_name , "Received AT cmd +ex1 with ? " , QCLI_AT_RESULT_OK_V01);
      }
      else if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_EQ_V01| QCLI_AT_MASK_QU_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        e = qapi_atfwd_send_resp(atcmd_name , "Received AT cmd +ex1 with =? " , QCLI_AT_RESULT_OK_V01);
      }
      else if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_EQ_V01| QCLI_AT_MASK_AR_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        QCLI_Printf(qcli_atfwd_cli_app_handle, "The parameters received are %s\n",at_fwd_params);
        e = qapi_atfwd_send_resp(atcmd_name , "Received AT cmd +ex1 with Arguments" , QCLI_AT_RESULT_OK_V01);
      }
    }
    else if (!strncasecmp(atcmd_name, "+ex2", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      // Test the timer bail out scenario by not sending any response for the atcmd +ex2
      // e = qapi_atfwd_send_resp(atcmd_name, "buf less than max and response as complete", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex3", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex4", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex5", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "81-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex6", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "97-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnop", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex7", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "98-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopq", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex8", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "108-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex9", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "196-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghij", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex10", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "197-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijk", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex11", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "212-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex12", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "394-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex13", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "at error with response as complete", QCLI_AT_RESULT_ERROR_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex14", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "498-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex15", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex16", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex17", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "at error with response as complete", QCLI_AT_RESULT_ERROR_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex18", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex19", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "at error with response as complete", QCLI_AT_RESULT_ERROR_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex20", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
    }
    else 
    {
      e = QAPI_ERR_NO_ENTRY;
    }

    if (e == QAPI_OK)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully sent response\n");
    }
    else if (e == QAPI_ERR_INVALID_PARAM)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response as the result type is unsupported\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Please send the response with supported "
                                             "result type : Supported are 0, 1\n");
    }
    else if (e == QAPI_ERR_NOT_SUPPORTED)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to send response for %s " 
                                              "when not expected\n", atcmd_name);
    }
    else if (e == QAPI_ERR_NO_ENTRY)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Please send the response for "
                                             "the AT Cmd %s from the QCLI\n", atcmd_name);
    }
    else
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
    }
  }
  else
  {
    if (mask != 0)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Unsuccessful Registeration\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to register : More than limit OR Unsupported Cmds OR Already Registered Cmds\n");
    }
    else
    {
      total_cmd_reg--;

      QCLI_Printf(qcli_atfwd_cli_app_handle, "De-registered AT cmd\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Remaining AT cmds reg with "
                                             "this callback %d\n", total_cmd_reg);

      if (total_cmd_reg == 0)
      {
        if (qapi_atfwd_release_byte_pool(at_fwd_callback) != QAPI_OK)
        {
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to release Userspace"
                                                 " Byte Memory. Pls check!\n");
        }
        user_space_pool_init = FALSE;
      }
    }
  }
  return;
}

void at_fwd_callback1(boolean is_reg, char *atcmd_name, uint8* at_fwd_params, uint8 mask, uint32 at_handle)
{
  int32_t e = -1;
  static int total_cmd_reg_cb1 = 0;

  QCLI_Printf(qcli_atfwd_cli_app_handle, "In at_fwd_callback1\n");
  if(is_reg)
  {
    if (mask == QCLI_AT_MASK_EMPTY)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Last registered AT cmd %s\n",atcmd_name);

      total_cmd_reg_cb1+=at_handle;

      QCLI_Printf(qcli_atfwd_cli_app_handle, "Total Registered AT cmds in ATFwD"
                  "with this callback %d \n",total_cmd_reg_cb1);
      return;
    }

    QCLI_Printf(qcli_atfwd_cli_app_handle, "Atcmd %s is registered\n",atcmd_name);

    if (!strncasecmp(atcmd_name, "+ex1", strlen(atcmd_name)))
    {
      if (mask == (QCLI_AT_MASK_NA_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        e = qapi_atfwd_send_resp(atcmd_name, "Received AT cmd +ex1 with Only Name", QCLI_AT_RESULT_OK_V01);
      }
      else if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_QU_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        e = qapi_atfwd_send_resp(atcmd_name , "Received AT cmd +ex1 with ? " , QCLI_AT_RESULT_OK_V01);
      }
      else if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_EQ_V01| QCLI_AT_MASK_QU_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        e = qapi_atfwd_send_resp(atcmd_name , "Received AT cmd +ex1 with =? " , QCLI_AT_RESULT_OK_V01);
      }
      else if (mask == (QCLI_AT_MASK_NA_V01 | QCLI_AT_MASK_EQ_V01| QCLI_AT_MASK_AR_V01))
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
        QCLI_Printf(qcli_atfwd_cli_app_handle, "The parameters received are %s\n",at_fwd_params);
        e = qapi_atfwd_send_resp(atcmd_name , "Received AT cmd +ex1 with Arguments" , QCLI_AT_RESULT_OK_V01);
      }
    }
    else if (!strncasecmp(atcmd_name, "+ex2", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      // Test the timer bail out scenario by not sending any response for the atcmd +ex2
      // e = qapi_atfwd_send_resp(atcmd_name, "buf less than max and response as complete", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex3", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_ERROR_V01);
    }
    else
    {
      e = QAPI_ERR_NO_ENTRY;
    }

    if (e == QAPI_OK)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully sent response\n");
    }
    else if (e == QAPI_ERR_INVALID_PARAM)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response as the result type is unsupported\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Please send the response with supported "
                                             "result type : Supported are 0, 1\n");
    }
    else if (e == QAPI_ERR_NOT_SUPPORTED)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to send response for %s " 
                                              "when not expected\n", atcmd_name);
    }
    else if (e == QAPI_ERR_NO_ENTRY)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "The following ATCMD %s is NOT supported on Thread 1\n",atcmd_name);
    }
    else
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
    }

  }
  else
  {
    if (mask != 0)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Unsuccessful Registeration\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to register : More than limit OR Unsupported Cmds OR Already Registered Cmds\n");
  }
    else
    {
      total_cmd_reg_cb1--;
      QCLI_Printf(qcli_atfwd_cli_app_handle, "De-registered AT cmd \n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Remaining AT cmds reg with "
                                           "this callback %d\n", total_cmd_reg_cb1);
	
      if (total_cmd_reg_cb1 == 0)
      {
        if (qapi_atfwd_release_byte_pool(at_fwd_callback1) != QAPI_OK)
        {
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to release Userspace"
                                                 " Byte Memory. Pls check!\n");
        }
        user_space_pool_1 =  FALSE;
      }
    }
  }
  return;
}

void at_fwd_callback2(boolean is_reg, char *atcmd_name, uint8* at_fwd_params, uint8 mask, uint32 at_handle)
{
  int32_t e = -1;
   static int total_cmd_reg_cb2 = 0;

  QCLI_Printf(qcli_atfwd_cli_app_handle, "In at_fwd_callback2\n");
  if(is_reg)
  {
    if (mask == QCLI_AT_MASK_EMPTY)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Last registered AT cmd %s\n",atcmd_name);

      total_cmd_reg_cb2+=at_handle;


      QCLI_Printf(qcli_atfwd_cli_app_handle, "Total Registered AT cmds in ATFwD"
                  "with this callback %d \n",total_cmd_reg_cb2);
      return;
    }
		
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Atcmd %s is registered\n",atcmd_name);

    if (!strncasecmp(atcmd_name, "+ex10", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "197-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijk", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex11", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "212-abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz", QCLI_AT_RESULT_OK_V01);
    }
    else if (!strncasecmp(atcmd_name, "+ex12", strlen(atcmd_name)))
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully received callback of Atcmd %s\n",atcmd_name);
      e = qapi_atfwd_send_resp(atcmd_name, "", QCLI_AT_RESULT_OK_V01);
    }
    else
    {
      e = QAPI_ERR_NO_ENTRY;
    }

    if (e == QAPI_OK)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully sent response\n");
    }
    else if (e == QAPI_ERR_INVALID_PARAM)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response as the result type is unsupported\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Please send the response with supported "
                                             "result type : Supported are 0, 1\n");
    }
    else if (e == QAPI_ERR_NOT_SUPPORTED)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to send response for %s " 
                                              "when not expected\n", atcmd_name);
    }
    else if (e == QAPI_ERR_NO_ENTRY)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "The following ATCMD %s is NOT supported on Thread 2\n",atcmd_name);
    }
    else
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
    }

  }
  else
  {
    if (mask != 0)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Unsuccessful Registeration\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to register : More than limit OR Unsupported Cmds OR Already Registered Cmds\n");
    }
    else
    {
      total_cmd_reg_cb2--;
      QCLI_Printf(qcli_atfwd_cli_app_handle, "De-registered AT cmd\n");
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Remaining AT cmds reg with "
                                           "this callback %d\n", total_cmd_reg_cb2);
	
      if (total_cmd_reg_cb2 == 0)
      {
        if (qapi_atfwd_release_byte_pool(at_fwd_callback2) != QAPI_OK)
        {
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to release Userspace"
                                                 " Byte Memory. Pls check!\n");
        }
        user_space_pool_2 = FALSE;
      }
    }
  }
  return;
}

static QCLI_Command_Status_t create_atfwd_thread(uint32_t Parameter_Count, QCLI_Parameter_t *Parameter_List)
{
  int thread_number;
  char *cmd;
  int res = 1;

  if (Parameter_Count == 0)
  {
    goto parm_error;
  }

  cmd = (char *)Parameter_List[0].String_Value;
  if(strncmp(cmd,"start",5) == 0)
  {
    if (Parameter_Count != 2)
    {
      goto parm_error;
    }

    thread_number = Parameter_List[1].Integer_Value;

    if(thread_number == 1)
    {
      res = create_atfwd_thread1();

      if(res != TX_SUCCESS) 
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle,"Unable to create Thread 1\n");
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully Created Thread 1\n");
      }
    }
    else if(thread_number == 2)
    {
      res = create_atfwd_thread2();

      if(res != TX_SUCCESS) 
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle,"Unable to create Thread 2\n");
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully Created Thread 2\n");
      }
    }
    else
    {
      res = TX_OPTION_ERROR;
      QCLI_Printf(qcli_atfwd_cli_app_handle,"Please enter a valid Thread Number. Supported are 1,2\n");
    }
  }
  else
  {
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Invalid subcommand: %s\n", cmd);
    goto parm_error;
  }

  if (res != TX_SUCCESS)
  {
    QCLI_Printf(qcli_atfwd_cli_app_handle, "%s failed\n",cmd);
    return QCLI_STATUS_ERROR_E;
  }
  else
  {
    return QCLI_STATUS_SUCCESS_E;
  }

  parm_error:
    return QCLI_STATUS_USAGE_E;
}

/*****************************************************************************
 *       [0]             [1]          [2]             [3]
 * Atfwd reg          <at_cmds>
 * Atfwd sendresp    <atcmd_name>  <response_buf>   <result>
 * Atfwd sendurc     <atcmd_name>  <response_buf> 
 *
 *****************************************************************************/
static QCLI_Command_Status_t atfwd(uint32_t Parameter_Count, QCLI_Parameter_t *Parameter_List)
{
    int32_t e = -1;
    char *cmd;
    char *at_cmd_name_list, *buf, *at_urc;
    char *atcmd_name;
    uint32_t result = 0;

    if (Parameter_Count == 0)
    {
      goto parm_error;
    }

    cmd = (char*)Parameter_List[0].String_Value;

    /*
     * atfwd reg +ex1;+ex2
     */
    if (strncmp(cmd, "reg", 3) == 0)
    {
      if (Parameter_Count != 2)
      {
          goto parm_error;
      }

      if (!user_space_pool_init)
      {
        if (qapi_atfwd_Pass_Pool_Ptr(at_fwd_callback, byte_pool_qcli) != QAPI_OK)
        {
          QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to alloc User space memory"
                                                 "in at_fwd_callback\n");
          return QCLI_STATUS_ERROR_E;
        }
        user_space_pool_init = TRUE;
      }

      at_cmd_name_list = (char*)Parameter_List[1].String_Value;

      QCLI_Printf(qcli_atfwd_cli_app_handle, "Received registeration request\n");

      e = qapi_atfwd_reg(at_cmd_name_list, at_fwd_callback);

      if (e != QAPI_OK)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to Process the received Registeration Request\n");
        return QCLI_STATUS_ERROR_E;
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Completed Processing the received Registeration Request\n");
      }
    }

    /*
     * atfwd dereg +ex1;+ex2
     */
    else if (strncmp(cmd, "dereg", 5) == 0)
    {
      if (Parameter_Count != 2)
      {
          goto parm_error;
      }

      at_cmd_name_list = (char*)Parameter_List[1].String_Value;

      QCLI_Printf(qcli_atfwd_cli_app_handle, "Received De-registeration request\n");

      e = qapi_atfwd_dereg(at_cmd_name_list);

      if (e != QAPI_OK)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to Process the received De-Registeration Request\n");
        return QCLI_STATUS_ERROR_E;
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Completed Processing the received De-Registeration Request\n");
      }
    }

    /*
     * atfwd sendresponse +ex1 testresp 0
     */
    else if (strncmp(cmd, "sendresp", 8) == 0)
    {
      if (Parameter_Count < 3 || Parameter_Count > 4)
      {
        goto parm_error;
      }

      atcmd_name = (char*)Parameter_List[1].String_Value;

      if (Parameter_Count == 3)
      {
        if (Parameter_List[2].Integer_Is_Valid)
        {
          result = Parameter_List[2].Integer_Value;
        }
        else
        {
          goto parm_error;
        }
        buf = "";
      }
      else if(Parameter_Count == 4)
      {
        buf = (char*)Parameter_List[2].String_Value;

        if (Parameter_List[3].Integer_Is_Valid)
        {
          result = Parameter_List[3].Integer_Value;
        }
      }

      e = qapi_atfwd_send_resp(atcmd_name, buf, result);

      if (e == QAPI_OK)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully sent response\n");
      }
      else if (e == QAPI_ERR_INVALID_PARAM)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response as the result type is unsupported\n");
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Please send the response with supported "
                                                "result type : Supported are 0, 1\n");
        return QCLI_STATUS_ERROR_E;
      }
      else if (e == QAPI_ERR_NOT_SUPPORTED)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Trying to send response for %s " 
                                                "when not expected\n", atcmd_name);
        return QCLI_STATUS_ERROR_E;
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
        return QCLI_STATUS_ERROR_E;
      }

    }

    /*
    * atfwd sendurc testurcresp 0
    */
    else if (strncmp(cmd, "sendurc", 7) == 0)
    {
      if (Parameter_Count != 3)
      {
        goto parm_error;
      }

      atcmd_name = (char*)Parameter_List[1].String_Value;

      at_urc = (char*)Parameter_List[2].String_Value;

      e = qapi_atfwd_send_urc_resp(atcmd_name, at_urc);

      if (e == QAPI_OK)
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully sent response\n");
      }
      else
      {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "Failed to send response\n");
        return QCLI_STATUS_ERROR_E;
      }
    }
    else
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Invalid subcommand: %s\n", cmd);
      goto parm_error;
    }

    if (e)
    {
        QCLI_Printf(qcli_atfwd_cli_app_handle, "%s failed\n", cmd);
        return QCLI_STATUS_ERROR_E;
    }
    else
    {
        return QCLI_STATUS_SUCCESS_E;
    }

parm_error:
    return QCLI_STATUS_USAGE_E;
}

static int create_atfwd_thread1()
{
  int ret;
  CHAR *thread_stack_pointer1 = NULL;

  txm_module_object_allocate(&atfwd_thread_handle1, sizeof(TX_THREAD));

  tx_byte_allocate(byte_pool_qcli, (VOID **) &thread_stack_pointer1, ATFWD_STACK_SIZE, TX_NO_WAIT);

  /* Create the extensible object application thread.  */
  ret = tx_thread_create(atfwd_thread_handle1, "atfwd_test_thread1", perform_atfwd_test1,
                         0, thread_stack_pointer1, ATFWD_STACK_SIZE,
                         ATFWD_PRIORITY, ATFWD_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  return ret;
}

void perform_atfwd_test1(void *args)
{
  char *at_cmd_name_list;
  int32_t e = -1;


  at_cmd_name_list = "+ex1;+ex2;+ex3";

  QCLI_Printf(qcli_atfwd_cli_app_handle, "Received registeration request\n");

  if (!user_space_pool_1)
  {
    if (qapi_atfwd_Pass_Pool_Ptr(at_fwd_callback1, byte_pool_qcli) != QAPI_OK)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to alloc User space memory"
                                              "in at_fwd_callback\n");
      return ;
    }
    user_space_pool_1 = TRUE;
  }
  
  e = qapi_atfwd_reg(at_cmd_name_list, at_fwd_callback1);

  if (e != QAPI_OK)
  {
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Registeration is not Successful\n");
  }
  else
  {
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully registered +ex1;+ex2;+ex3 through Thread 1\n");
  }
  return;
}

static int create_atfwd_thread2()
{
  int ret;
  CHAR *thread_stack_pointer2 = NULL;
  txm_module_object_allocate(&atfwd_thread_handle2, sizeof(TX_THREAD));
  
  tx_byte_allocate(byte_pool_qcli, (VOID **) &thread_stack_pointer2, ATFWD_STACK_SIZE, TX_NO_WAIT);


  /* Create the extensible object application thread.  */
  ret = tx_thread_create(atfwd_thread_handle2, "atfwd_test_thread2", perform_atfwd_test2,
                         0, thread_stack_pointer2, ATFWD_STACK_SIZE,
                         ATFWD_PRIORITY, ATFWD_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  return ret;
}

void perform_atfwd_test2(void *args)
{
  char *at_cmd_name_list;
  int32_t e = -1;


  at_cmd_name_list = "+ex10;+ex11;+ex12";

  QCLI_Printf(qcli_atfwd_cli_app_handle, "Received registeration request\n");

  if (!user_space_pool_2)
  {
    if (qapi_atfwd_Pass_Pool_Ptr(at_fwd_callback2, byte_pool_qcli) != QAPI_OK)
    {
      QCLI_Printf(qcli_atfwd_cli_app_handle, "Unable to alloc User space memory"
                                              "in at_fwd_callback\n");
      return;
    }
    user_space_pool_2 = TRUE;
  }
  e = qapi_atfwd_reg(at_cmd_name_list, at_fwd_callback2);

  if (e != QAPI_OK)
  {
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Registeration is not Successful\n");
  }
  else
  {
    QCLI_Printf(qcli_atfwd_cli_app_handle, "Successfully registered +ex10;+ex11;+ex12 through Thread 2\n");
  }
  return;
}
