/*!
  @file
  at_demo.c
  @brief
  QCLI implementation for AT.
*/


/*===========================================================================
  Copyright (c) 2017  by Qualcomm Technologies, Inc.  All Rights Reserved.

  Qualcomm Technologies Proprietary


  Export of this technology or software is regulated by the U.S. Government.

  Diversion contrary to U.S. law prohibited.



  All ideas, data and information contained in or disclosed by

  this document are confidential and proprietary information of

  Qualcomm Technologies, Inc. and all rights therein are expressly reserved.

  By accepting this material the recipient agrees that this material

  and the information contained therein are held in confidence and in

  trust and will not be used, copied, reproduced in whole or in part,

  nor its contents revealed in any manner to others without the express

  written permission of Qualcomm Technologies, Inc.

  ======================================================================*/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include "../qcli/qcli.h"
#include "../qcli/qcli_api.h"
#include "qapi/qapi.h"
#include "qapi/qapi_status.h"
#include "qapi/qapi_psm.h"
#include "qapi/qapi_types.h"
#include "qapi/qapi_psm_status.h"
#include "qapi/qapi_fs.h"
#include "qapi/qapi_timer.h"
#include "qapi/qapi_ns_utils.h"
#include "qapi/qapi_socket.h"
#include "qapi/qapi_dam.h"
#include "msgcfg.h"
#include "msg_mask.h"
#include "qapi_diag.h"
#include "qflog_utils.h"

#define SIMCOM_MAX_LOG_MSG_SIZE  100
#define SIMCOM_LOG_MSG( fmt, ... )                                           \
    {                                                                            \
        char log_fmt[ SIMCOM_MAX_LOG_MSG_SIZE +1] = {0}; \
        char log_buf[ SIMCOM_MAX_LOG_MSG_SIZE +1] = {0}; \
        strlcpy(log_fmt, "SIMCOM_%s: ", sizeof(log_fmt));\
        strlcat(log_fmt, fmt, sizeof(log_fmt));\
        simcom_format_at_log_msg( log_buf, SIMCOM_MAX_LOG_MSG_SIZE, log_fmt, __func__, ##__VA_ARGS__ );\
        QAPI_MSG_SPRINTF( MSG_SSID_LINUX_DATA, MSG_LEGACY_HIGH, "%s", log_buf );\
    }

static QCLI_Group_Handle_t s_qcli_at_handle;

/*  Encapsulation qapi interface method*/
static QCLI_Command_Status_t atcmd(uint32_t Parameter_Count, QCLI_Parameter_t *Parameter_List);
static void At_Output_Cb(void);

/* atcmd commands list */
const QCLI_Command_t s_at_cmd_list[] =
{
    /* Command_Function, Start_Thread, Command_String, Usage_String, Description */
    {atcmd, false, "atcmd", "<at command>" , "Send At command to modem",NULL},
};

/* add atcmd to commans list */
const QCLI_Command_Group_t s_at_cmd_group =
{
    "AT",              /* Group_String: will display cmd prompt as "PSM> " */
    sizeof(s_at_cmd_list)/sizeof(s_at_cmd_list[0]),   /* Command_Count */
    s_at_cmd_list        /* Command_List */
};

void simcom_format_at_log_msg ( char *buf_ptr, int buf_size, char *fmt, ...)
{
    va_list ap;
    va_start( ap, fmt );

    if ( NULL != buf_ptr && buf_size > 0 )
    {
        vsnprintf( buf_ptr, buf_size, fmt, ap );
    }

    va_end( ap );
} /* ril_format_log_msg */

void Initialize_at_Demo (void)
{
    /* Attempt to reqister the Command Groups with the qcli framework.*/
    s_qcli_at_handle = QCLI_Register_Command_Group(NULL, &s_at_cmd_group);
    if (s_qcli_at_handle)
    {
        QCLI_Printf(s_qcli_at_handle, "ATCMD Registered\n");
    }
    return;
}

unsigned char data[2048] = {0};  
unsigned char tempBuf[256] = {0};  
//in this callback func, the stack is limited, please don't use big array
static void At_Output_Cb(void)
{
   int len = 0;  
   int outLen = 0;
   int i = 0;
	
	memset(data,0,2048);   
	do
	{
		len = qapi_DAM_Visual_AT_Output((unsigned char *)&data[outLen],2048-outLen);
		outLen += len;
		SIMCOM_LOG_MSG("At_Output_Cb,outLen=%d", outLen); 
		if (outLen > 2048)
		{
			break;
		}
	}while(len > 0);

	if (outLen > 0)
	{
		do 
		{
			memset(tempBuf,0,256);
			if (outLen > 255)
			{
				memcpy(tempBuf,&data[i],255);
				i += 255;
				outLen -= 255;
			}
			else
			{
				memcpy(tempBuf,&data[i],strlen((char *)&data[i]));
				outLen = 0;
			}
			QCLI_Printf(s_qcli_at_handle, "%s",tempBuf);
		}while(outLen > 0);
	}
}

static QCLI_Command_Status_t atcmd(uint32_t Parameter_Count, QCLI_Parameter_t *Parameter_List)
{   
    if (Parameter_Count == 1)  
    { 
        unsigned char data[1024] = {0};       

		qapi_DAM_Visual_AT_Open(At_Output_Cb);
        memset(data,0,1024);   
        memcpy(data,Parameter_List[0].String_Value,strlen((char *)Parameter_List[0].String_Value));
        
        memcpy(data+strlen((char *)data),"\r",1);
        qapi_DAM_Visual_AT_Input(data,strlen((char *)data));
        SIMCOM_LOG_MSG("atcmd is :%s,%d", data,strlen((char *)data)); 
    }
    else 
    {
        qapi_force_modem_sleep(0);
        SIMCOM_LOG_MSG("atcmd is :s,d" ); 
        QFLOG_MSG(MSG_SSID_DFLT,MSG_MASK_2, "Presence sensor application successfully registered ");
        return QCLI_STATUS_USAGE_E;     
    }
    
    return QCLI_STATUS_SUCCESS_E;   
}


